package be.businesstraining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import be.businesstraining.domain.Product;

@SpringBootTest(classes = {Product.class})
class Lab03Step4SpringBootMicroserviceWithDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
