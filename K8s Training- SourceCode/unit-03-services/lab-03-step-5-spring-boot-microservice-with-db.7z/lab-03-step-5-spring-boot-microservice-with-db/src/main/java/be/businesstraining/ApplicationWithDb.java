package be.businesstraining;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationWithDb {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationWithDb.class, args);
	}

}
