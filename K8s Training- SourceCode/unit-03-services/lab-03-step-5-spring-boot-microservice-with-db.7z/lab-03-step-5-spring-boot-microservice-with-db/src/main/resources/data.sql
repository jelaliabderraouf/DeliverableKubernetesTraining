insert into Products(id, name,unitPrice) values ('PROD001', 'SSD DISK 1 TO', 450.5);
insert into Products(id, name,unitPrice) values ('PROD002', 'LED Monitor 24inch', 270.5);
insert into Products(id, name,unitPrice) values ('PROD003', 'Azerty Multimedia Keyboard', 150.5);
insert into Products(id, name,unitPrice) values ('PROD004', 'Lazer Wireless mouse', 15.5);